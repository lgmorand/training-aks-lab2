# hello-world-nodejs

> A simple hello world app written in NodeJS.

## Getting started

```sh
# Install dependencies
npm ci

# Run the application
npm start
```
